function changeLights() {
    var redLight = document.getElementById('red');
    var yellowLight = document.getElementById('yellow');
    var greenLight = document.getElementById('green');
  
    var toggle = false; 
  
    setInterval(function() {
      toggle = !toggle; 
      if (toggle) {
        yellowLight.style.backgroundColor = 'yellow'; 
      } else {
        yellowLight.style.backgroundColor = '#777'; 
      }
    }, 1000); 
  
    
    redLight.style.backgroundColor = '#777';
    greenLight.style.backgroundColor = '#777';
  }
  
  changeLights(); 