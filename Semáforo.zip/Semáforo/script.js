function changeLights() {
  var redLight = document.getElementById('red');
  var yellowLight = document.getElementById('yellow');
  var greenLight = document.getElementById('green');

  setTimeout(function() {
    redLight.style.backgroundColor = 'red';
    yellowLight.style.backgroundColor = '#777';
    greenLight.style.backgroundColor = '#777';

    setTimeout(function() {
      redLight.style.backgroundColor = '#777';
      yellowLight.style.backgroundColor = '#777';
      greenLight.style.backgroundColor = 'green';

      setTimeout(function() {
        redLight.style.backgroundColor = '#777';
        yellowLight.style.backgroundColor = 'yellow';
        greenLight.style.backgroundColor = '#777';

        setTimeout(function() {
          changeLights(); 
        }, 2000);
      }, 5000); 
    }, 5000); 
  }, 0); 
}

changeLights(); //